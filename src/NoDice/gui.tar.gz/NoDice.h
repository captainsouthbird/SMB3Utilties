#ifndef _NODICE_H
#define _NODICE_H

// PPU stuff
#define PPU_PORTAL_X	272
#define PPU_PORTAL_Y	44

extern BITMAP *PPU_portal;
void ppu_init();
void ppu_set_BG_bank(unsigned char bank, unsigned char to0800);
void ppu_configure_for_level();
void ppu_draw();
void ppu_shutdown();

extern struct _ppu_selected_generator
{
	int select_level;					// When generators overlap and we're determining which one to select
	int frame_counter;					// Frame counter; used to determine what generators were potentially selectable last time we checked
	struct NoDice_the_level_generator *gen;	// The generator currently selected

	int moved_yet;						// Set if generator has actually moved yet
	int mouse_start_abs_x,
		mouse_start_abs_y;				// Mouse drag starting absolute X/Y
	int mouse_last_row,
		mouse_last_col;				// Determine last "row/column" the mouse was on to determine if we've moved
} ppu_selected_generator;


// GUI controls
#define SPINRANGE(min, max) (void *)((((min) & 0xFFFF) << 16) | ((max) & 0xFFFF))

int d_push_button_proc(int msg, DIALOG *d, int c);
int d_spinedit_proc(int msg, DIALOG *d, int c);
int d_combobox_proc(int msg, DIALOG *d, int c);
int d_text_clearrect_proc(int msg, DIALOG *d, int c);

void d_level_edit_updateForSelect();

extern struct _gui_gen_state
{
	unsigned char p[GEN_MAX_PARAMS];	// Generator param values

	const struct NoDice_generator *selected_gen;	// Selected generator (from droplist)

	struct _insert_mode
	{
		unsigned short addr;
		int state;	// 0 = Not inserting, 1 = Waiting for input, 2 = Ready to insert
	} insert_mode;		// Set if in insert mode

	int dirty;			// Set when any value has changed
} gui_gen_state;

void gui_state_update();

// Edit stuff
void edit_do();
void edit_transform_sel_gen(int diff_row, int diff_col);
void edit_6502_timeout();
void edit_level_load(unsigned char tileset, const struct NoDice_the_levels *level);
void edit_level_save();

#endif
