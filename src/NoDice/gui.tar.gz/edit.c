#include <allegro.h>
#include <limits.h>
#include <stdio.h>
#include "NoDiceLib.h"
#include "NoDice.h"

#define UNDO_STACK_LIMIT	100	// FIXME: User-configurable!

static void undo_mark();
static void undo_revert();

static const struct NoDice_the_levels *edit_cur_level;
static char path_buffer[PATH_MAX];

// Timeout routine to stop the 6502 if it appears to have frozen
void edit_6502_timeout(void)
{
	NoDice_Run6502_Stop = RUN6502_TIMEOUT;
}
END_OF_FUNCTION(edit_6502_timeout)

static int keylock(int keycode, unsigned char *keylock)
{
	if(key[keycode])
	{
		if(!*keylock)
		{
			*keylock = 1;
			return 1;
		}
	}
	else
		*keylock = 0;

	return 0;
}
static unsigned char keylock_pgup, keylock_pgdn, keylock_z;

// Remove specified generator from list (NOTE: Does not free it!!)
static void level_gen_remove(struct NoDice_the_level_generator *remove)
{
	// If the to-be-removed element is the first, then simply replace the first...
	if(NoDice_the_level.generators == remove)
	{
		// The next element is the new first element
		NoDice_the_level.generators = remove->next;

		// The new first element needs to have no previous!
		if(NoDice_the_level.generators != NULL)
			NoDice_the_level.generators->prev = NULL;
	}
	else
	{
		// Non-first element general removal
		remove->prev->next = remove->next;

		if(remove->next != NULL)
			remove->next->prev = remove->prev;
	}
}

// Inserts the specified generator after "insert_after"
// If "insert_after" is NULL, inserts as first element
static void level_gen_insert(struct NoDice_the_level_generator *insert_after, struct NoDice_the_level_generator *insert)
{
	if(insert_after == NULL)
	{
		// As long as an item exists, needs to acknowledge "insert" as its predecessor
		if(NoDice_the_level.generators != NULL)
		{
			NoDice_the_level.generators->prev = insert;
			insert->next = NoDice_the_level.generators;
		}

		// New first element
		insert->prev = NULL;
		NoDice_the_level.generators = insert;
	}
	else
	{
		// Non-first element general insert
		insert->next = insert_after->next;

		if(insert_after->next != NULL)
			insert_after->next->prev = insert;

		insert->prev = insert_after;
		insert_after->next = insert;
	}
}

// Get the "index" of the generator
static int level_gen_index(struct NoDice_the_level_generator *sel)
{
	int result = -1;
	struct NoDice_the_level_generator *cur = NoDice_the_level.generators;

	while(cur != NULL)
	{
		result++;

		if(cur == sel)
			break;

		cur = cur->next;
	}

	return result;
}


static void level_gen_push_back()
{
	// Hold pointer to element before selected's previous,
	// where we need to reinsert it to move it back one
	struct NoDice_the_level_generator *sel_prev_prev = ppu_selected_generator.gen->prev->prev;

	// Step 1: Remove selected generator
	level_gen_remove(ppu_selected_generator.gen);

	// Step 2: Insert selected generator back into list
	level_gen_insert(sel_prev_prev, ppu_selected_generator.gen);
}


static void level_gen_push_forward()
{
	// Hold pointer to element after selected, where we
	// need  to reinsert it after to move it forward one
	struct NoDice_the_level_generator *sel_next = ppu_selected_generator.gen->next;

	// Step 1: Remove selected generator
	level_gen_remove(ppu_selected_generator.gen);

	// Step 2: Insert selected generator back into list
	level_gen_insert(sel_next, ppu_selected_generator.gen);
}


// Get the generator at the specified index
static struct NoDice_the_level_generator *level_gen_at_index(int index)
{
	int result = -1;
	struct NoDice_the_level_generator *cur = NoDice_the_level.generators;

	while(cur != NULL)
	{
		result++;

		if(result == index)
			return cur;

		cur = cur->next;
	}

	return NULL;
}


static int level_gen_count()
{
	int total = 0;
	struct NoDice_the_level_generator *cur = NoDice_the_level.generators;

	while(cur != NULL)
	{
		total++;
		cur = cur->next;
	}

	return total;
}


void edit_level_load(unsigned char tileset, const struct NoDice_the_levels *level)
{
	// Remember level we're looking at
	edit_cur_level = level;

	// FIXME CLEANUP
	NoDice_load_level(tileset, level->layoutlabel, level->objectlabel);

	if(NoDice_Run6502_Stop != RUN6502_STOP_END)
	{
		char buffer[48];

		const char *err[] =
		{
			"RUN6502_STOP_NOTSTOPPED",
			"RUN6502_STOP_END",
			"RUN6502_INIT_ERROR",
			"RUN6502_LEVEL_OORW_LOW",
			"RUN6502_LEVEL_OORW_HIGH",
			"RUN6502_TIMEOUT",
			"RUN6502_GENERATOR_TOO_LARGE",
		};

		sprintf(buffer, "Error %s", err[NoDice_Run6502_Stop]);

		alert(buffer, NULL, NULL, "OK", NULL, 0, 0);
	}

	// Initial undo mark
	undo_mark();
}


static void level_reload(int expected_generator_count)
{
	const char *s3 = "";

	enum
	{
		REVERT_NONE = -1,			// All good, no revert!

		REVERT_INIT_ERROR		= 0,	// Probably 6502 core initialization error
		REVERT_GENCOUNT_MISMATCH = 1,	// Revert because we wound up with more or less generators than expected
		REVERT_OFFSCREEN_LOW	= 2,	// Revert because a write was attempted at below 0x6000
		REVERT_OFFSCREEN_HIGH	= 3,	// Revert because a write was attempted at above 0x794F
		REVERT_TIMEOUT			= 4,	// Revert because it appears the 6502 core froze
		REVERT_GENTOOLARGE		= 5,	// Revert because a generator was too large

		REVERT_TOTAL
	} revertReason = REVERT_NONE;

	const char *revertReasons[REVERT_TOTAL] =
	{
		"Internal error",	// REVERT_INIT_ERROR
		"Did not return with the expected number of generators",	// REVERT_GENCOUNT_MISMATCH
		"Generator wrote out of tile memory bounds (low, top/left)",	// REVERT_OFFSCREEN_LOW
		"Generator wrote out of tile memory bounds (high, bottom/right)",	// REVERT_OFFSCREEN_HIGH
		"6502 core appears to have frozen (NOTE: May have to change config \"coretimeout\")",	// REVERT_TIMEOUT
		"A generator appeared to be too large",	// REVERT_GENTOOLARGE
	};

	// Install a timer to check for lockups of the 6502 core
	install_int(edit_6502_timeout, NoDice_config.core6502_timeout);

	// Reload level
	NoDice_load_level_raw_data(NULL, 0, 0);

	// Remove the timer
	remove_int(edit_6502_timeout);

	// Make sure no 6502 errors were reported...
	if(NoDice_Run6502_Stop == RUN6502_STOP_END)
	{
		int actual_count = level_gen_count();

		// Verify that the generator count did not change!
		if(expected_generator_count != actual_count)
			revertReason = REVERT_GENCOUNT_MISMATCH;
	}
	else
	{
		switch(NoDice_Run6502_Stop)
		{
		case RUN6502_INIT_ERROR:
			revertReason = REVERT_INIT_ERROR;
			s3 = NoDice_Error();
			break;

		case RUN6502_LEVEL_OORW_LOW:
			revertReason = REVERT_OFFSCREEN_LOW;
			break;

		case RUN6502_LEVEL_OORW_HIGH:
			revertReason = REVERT_OFFSCREEN_HIGH;
			break;

		case RUN6502_TIMEOUT:
			revertReason = REVERT_TIMEOUT;
			break;

		case RUN6502_GENERATOR_TOO_LARGE:
			revertReason = REVERT_GENTOOLARGE;
			break;

		default:
			revertReason = REVERT_INIT_ERROR;
			break;
		}
	}

	if(revertReason > REVERT_NONE)
	{
		alert("EDIT REVERTED", revertReasons[revertReason], s3, "OK", NULL, 0, 0);
		undo_revert();
	}
}

// Reloads level data with active generator set and verifies that
// the generator count afterward is what is expected.  This deals
// with a type of corruption that may cause additional "fake" generators
// to appear (may be solved by other range checks, but safe!)
static void level_reload_with_selection(int expected_generator_count)
{
	int old_sel_index;

	// Get old "index" of selection
	old_sel_index = level_gen_index(ppu_selected_generator.gen);

	// Reload level
	level_reload(expected_generator_count);

	// Restore selection
	ppu_selected_generator.select_level = 0;
	ppu_selected_generator.gen = level_gen_at_index(old_sel_index);
}


static struct edit_undo
{
	unsigned char *layout_data;
	int layout_data_size;
} undo_stack[UNDO_STACK_LIMIT];
static int
	undo_stack_pos = 0, 	// Position within stack
	undo_stack_bottom = 0,	// Current bottom of stack; moves circularly as needed
	undo_stack_total = 0;	// Total items in undo stack


// Add copy of level to undo buffer
static void undo_mark()
{
	struct edit_undo *undo = &undo_stack[undo_stack_pos];
	const unsigned char *layout_data;

	// If undo stack is maxed out, we move the bottom up
	if(undo_stack_total == UNDO_STACK_LIMIT)
	{
		// Free components from old bottom
		free(undo_stack[undo_stack_bottom].layout_data);

		undo_stack_bottom = (undo_stack_bottom + 1) % UNDO_STACK_LIMIT;
	}
	else
		undo_stack_total++;

	// Advance position in the undo stack
	undo_stack_pos = (undo_stack_pos + 1) % UNDO_STACK_LIMIT;

	// Copy layout data onto stack (no header)
	layout_data = NoDice_pack_level(&undo->layout_data_size, 0);

	// Allocate and copy data
	undo->layout_data = (unsigned char *)malloc(sizeof(unsigned char) * undo->layout_data_size);
	memcpy(undo->layout_data, layout_data, undo->layout_data_size);
}


// Pop an action and revert the change
static void undo_revert()
{
	// Make sure we're not at the bottom of the stack already
	if(undo_stack_total > 0)
	{
		struct edit_undo *undo;

		// Reverse position in the undo stack
		undo_stack_pos = (undo_stack_pos == 0) ? (UNDO_STACK_LIMIT - 1) : (undo_stack_pos - 1);

		// One less total
		undo_stack_total--;

		// Get this action...
		undo = &undo_stack[undo_stack_pos];

		// Going to reload based on undo stack! (FIXME: Handle error)
		NoDice_load_level_raw_data(undo->layout_data, undo->layout_data_size, 0);

		// Free the memory used by this undo
		free(undo->layout_data);

		// No longer selected anything
		memset(&ppu_selected_generator, 0, sizeof(ppu_selected_generator));
	}
}


void edit_do()
{
	int mod_ctrl = key[KEY_LCONTROL] || key[KEY_RCONTROL];

	if(key[KEY_INSERT])
		gui_gen_state.insert_mode.state = 1;

	if(gui_gen_state.insert_mode.state == 2)
	{
		int i, sel_index = 0;

		// Ready to insert a generator!
		struct NoDice_the_level_generator *cur = NoDice_the_level.generators,
			*insert = (struct NoDice_the_level_generator *)malloc(sizeof(struct NoDice_the_level_generator));

		insert->addr_start = gui_gen_state.insert_mode.addr;
		insert->type = gui_gen_state.selected_gen->type;
		insert->id = gui_gen_state.selected_gen->id;

		if(insert->type == GENTYPE_VARIABLE)
		{
			// Should be 3+
			insert->size = 2;

			// NOTE: The size of the generator is determined by the defined parameters
			// Always define all of the parameters!!
			for(i = 0; i < GEN_MAX_PARAMS && gui_gen_state.selected_gen->parameters[i].name != NULL; i++)
			{
				insert->p[i] = gui_gen_state.p[i];
				insert->size++;
			}
		}
		else
			insert->size = 3;

		// Set undo mark
		undo_mark();

		if(cur != NULL)
		{
			// Need to seek to last generator
			while(cur != NULL)
			{
				// This is the last generator...
				if(cur->next == NULL)
				{
					level_gen_insert(cur, insert);
					break;
				}

				sel_index++;
				cur = cur->next;
			}
		}
		else
		{
			// Empty level apparently...
			level_gen_insert(NULL, insert);
		}

		// Reload level
		level_reload(level_gen_count());

		//
		//ppu_selected_generator.select_level = 0;
		//ppu_selected_generator.gen = level_gen_at_index(old_sel_index);

		// Done with insert
		gui_gen_state.insert_mode.state = 0;
	}

	if(ppu_selected_generator.gen != NULL)
	{
		// If the current parameter has changed on the gui, we need to apply that...
		if(gui_gen_state.dirty)
		{
			int i;

			// Add an undo mark
			undo_mark();

			// Change the generator parameters
			for(i = 3; i <= ppu_selected_generator.gen->size; i++)
				ppu_selected_generator.gen->p[i - 3] = gui_gen_state.p[i - 3];

			// Reload level
			level_reload_with_selection(level_gen_count());

			// This will keep us up to date (especially if the edit
			// had to be reverted!!) and clear the dirty flag
			d_level_edit_updateForSelect();
		}



		if(key[KEY_DEL])
		{
			// Add an undo mark
			undo_mark();

			// Remove from level's generators
			level_gen_remove(ppu_selected_generator.gen);

			// Free this one!
			free(ppu_selected_generator.gen);

			// No longer selected anything
			memset(&ppu_selected_generator, 0, sizeof(ppu_selected_generator));

			// Reload level
			level_reload(level_gen_count());
		}

		// Push generator to rear
		if(keylock(KEY_PGDN, &keylock_pgdn))
		{
			// Make sure generator is not already all the way back
			if(ppu_selected_generator.gen->prev != NULL)
			{
				// Add an undo mark
				undo_mark();

				// Push back!
				level_gen_push_back();

				// Reload level
				level_reload_with_selection(level_gen_count());
			}
		}

		if(keylock(KEY_PGUP, &keylock_pgup))
		{
			// Make sure generator is not already all the way forward
			if(ppu_selected_generator.gen->next != NULL)
			{
				// Add an undo mark
				undo_mark();

				// Push forward!
				level_gen_push_forward();

				// Reload level
				level_reload_with_selection(level_gen_count());
			}
		}
	}
	else
		// Nothing selected, nothing to do
		gui_gen_state.dirty = 0;

	if(mod_ctrl && keylock(KEY_Z, &keylock_z))
	{
		 undo_revert();
	}
}


void edit_transform_sel_gen(int diff_row, int diff_col)
{
	int cur_row, cur_col, target_row, target_col;

	// If this is the first move, set an undo mark
	if(!ppu_selected_generator.moved_yet)
	{
		undo_mark();
		ppu_selected_generator.moved_yet = 1;
	}

	cur_row = ppu_selected_generator.gen->ys / TILESIZE;
	cur_col = ppu_selected_generator.gen->xs / TILESIZE;

	target_row = cur_row + diff_row;
	target_col = cur_col + diff_col;

	if(!(NoDice_the_level.header.is_vert))
	{
		int cur_screen = cur_col / SCREEN_WIDTH;
		int target_screen = target_col / SCREEN_WIDTH;

		// Vertical transformation is pretty simple...
		if( target_row >= 0 && target_row < (SCREEN_BYTESIZE / SCREEN_WIDTH) )
			ppu_selected_generator.gen->addr_start += diff_row * SCREEN_WIDTH;

		// Horizontal transformation needs to pay attention to the screen!
		if(target_screen >= 0 && target_screen <= 15)
		{
			if(target_screen < cur_screen)
				ppu_selected_generator.gen->addr_start -= SCREEN_BYTESIZE - (SCREEN_WIDTH - 2) + diff_col;
			else if(target_screen > cur_screen)
				ppu_selected_generator.gen->addr_start += SCREEN_BYTESIZE - SCREEN_WIDTH + diff_col;
			else
				ppu_selected_generator.gen->addr_start += diff_col;
		}
	}
	else
	{
		// Things are much easier in vertical levels because the memory is linear!
		if(target_row >= 0 && target_row < (SCREEN_BYTESIZE_V / SCREEN_WIDTH) * 16 )
			ppu_selected_generator.gen->addr_start += diff_row * SCREEN_WIDTH;

		if(target_col >= 0 && target_col <= 15)
			ppu_selected_generator.gen->addr_start += diff_col;
	}

	// Reload level
	level_reload_with_selection(level_gen_count());
}


// This should be WAY MORE than enough; nesasm only allows labels up to something
// like 32 characters, and so even if you had 8 individual flags of 32 characters
// separated by " | " (35), max required is 35 * 8 = 280 characters
#define OPTION_STRING_LEN	512

static int option_string_add(char *opt_str, const char *addition, int *opt_str_pos)
{
	// The buffer space is limited...
	// Make sure we haven't hit the end of the buffer
	if(*opt_str_pos < (OPTION_STRING_LEN-1) )
	{
		int i;
		const char *additions[2] = { addition, " | " };

		for(i = 0; i < 2; i ++)
		{
			// Number of characters for next line of output
			int len = strlen(additions[i]), max = (OPTION_STRING_LEN-1) - *opt_str_pos;

			if(max > 0)
			{
				// Use strncat to limit number of characters we copy up to
				// what's remaining in the buffer
				strncat(opt_str, additions[i], max);

				// Advance position
				*opt_str_pos += len;
			}
			else
				// Not enough room!
				return 0;
		}

		return 1;
	}

	// Not enough room!!
	return 0;
}


static const struct NoDice_the_levels *edit_level_save_find_alternate()
{
	int i;
	const struct NoDice_the_levels *the_level = NULL;

	// FIXME: This process is kind of complicated; wonder if it could be done better?

	// Find the correct tileset that matches the alternate
	for(i = 0; i < NoDice_config.game.tileset_count; i++)
	{
		const struct NoDice_tileset *tileset = &NoDice_config.game.tilesets[i];
		if(tileset->id == NoDice_the_level.header.alt_level_tileset)
		{
			int j;

			// Found the tileset!  Hopefully we can find the level within...
			for(j = 0; j < tileset->levels_count; j++)
			{
				unsigned short addr;
				const struct NoDice_the_levels *level = &tileset->levels[j];

				// This part gets a little ugly; we need to resolve the labels
				// to addresses so we can see if these are the right labels to
				// apply here...
				addr = NoDice_get_addr_for_label(level->layoutlabel);

				// Check if the layout label is right; if not, we won't bother with
				// the object label...
				if(addr == NoDice_the_level.header.alt_level_layout)
				{
					addr = NoDice_get_addr_for_label(level->objectlabel);

					if(addr == NoDice_the_level.header.alt_level_objects)
					{
						// We found it!!
						the_level = level;

						// We're done!
						break;
					}
				}
			}
		}
	}

	return the_level;
}


static const char *edit_level_save_make_option_string(int header_index)
{
	int i, opt_str_pos = 0;
	static char opt_str[OPTION_STRING_LEN];
	const struct NoDice_headers *header = &NoDice_config.game.headers[header_index];
	unsigned char header_val = NoDice_the_level.header.option[header_index];

	// Blank out the string
	opt_str[0] = '\0';

	// Go through each option defined by the header_index to
	// determine the bit field constants...
	for(i = 0; i < header->options_list_count; i++)
	{
		int j;

		// This <options /> block...
		const struct NoDice_header_options *option_list = &header->options_list[i];

		// Special "flag" mode recognition -- if there is only a single
		// <option /> in the <options /> block, this is a flag, so we only
		// toggle it...
		if((option_list->options_count == 1) && (option_list->options[0].label != NULL))
		{
			// But only do anything if it's set, otherwise forget it
			if(header_val & option_list->mask)
			{
				// Bit set; add the mask, but abort if we run out of room (shouldn't happen, hopefully!!)
				if(!option_string_add(opt_str, option_list->options[0].label, &opt_str_pos))
					return NULL;
			}
		}
		else if(option_list->options_count > 1)
		{
			int resolved = 0;	// Flag set if label is resolved
			char alt_val[11];	// Small buffer in case we must enter value manually (enough for "(0-255 << 0-7)")

			// Get index value relative to the option
			unsigned char relative_value = (header_val & option_list->mask) >> option_list->shift;

			// Locate this value in the option list (hopefully!)
			for(j = 0; j < option_list->options_count; j++)
			{
				const struct NoDice_option *opt = &option_list->options[j];

				// If there's a defined label and the value matches the relative
				// value, then we have our label!
				if((opt->label != NULL) && (opt->value == relative_value))
				{
					// Push in the flag value if we can...
					if(!option_string_add(opt_str, opt->label, &opt_str_pos))
						return NULL;

					// We found it!
					resolved = 1;

					// Done!
					break;
				}
			}

			// We don't have a flag for this!  Just put in a raw value for now...
			if(!resolved)
			{
				snprintf(alt_val, sizeof(alt_val), "(%i << %i)", relative_value, option_list->shift);
				if(!option_string_add(opt_str, alt_val, &opt_str_pos))
					return NULL;
			}
		}
	}

	// Unlikely, but if we wound up with absolutely nothing, just return a zero
	if(strlen(opt_str) == 0)
		strcpy(opt_str, "0");
	else
	{
		int len = strlen(opt_str);

		// Trim off trailing " | ", if present
		if(opt_str[len-3] == ' ' && opt_str[len-2] == '|' && opt_str[len-1] == ' ')
			opt_str[len-3] = '\0';
	}

	return opt_str;
}


void edit_level_save()
{
	const char *build_err;
	const struct NoDice_the_levels *level_alternate;
	const unsigned char *level_data;
	int i, size, col = 0;
	FILE *asm_file;

	// The actual act of "saving" the level requires that first we rewrite
	// the asm file belonging to the level itself...
	snprintf(path_buffer, PATH_MAX, SUBDIR_LEVELS "/%s/%s" EXT_ASM, NoDice_the_level.tileset->path, edit_cur_level->layoutfile);
	asm_file = fopen(path_buffer, "w");

	if(!asm_file)
	{
		alert("Failed to write to level assembler file!", strerror(errno), "", "OK", NULL, 0, 0);
		return;
	}

	fputs("; WARNING: Autogenerated file!  Do not put extra data here; editor will not preserve it!\n", asm_file);

	level_alternate = edit_level_save_find_alternate();
	if(level_alternate != NULL)
	{
		// Found the alternate!  Use labels (preferred!)
		fprintf(asm_file,
				"\t.word %s\t; Alternate level layout\n"
				"\t.word %s\t; Alternate object layout\n",

			level_alternate->layoutlabel,
			level_alternate->objectlabel
				);
	}
	else
	{
		// Didn't find it, use addresses (not flexible!)
		fprintf(asm_file,
				"\t.word $%04X\t; Alternate level layout\n"
				"\t.word $%04X\t; Alternate object layout\n",

			NoDice_the_level.header.alt_level_layout,
			NoDice_the_level.header.alt_level_objects
				);
	}

	// Go through each header and add the header bytes
	for(i = 0; i < LEVEL_HEADER_COUNT; i++)
	{
		const char *next_header = edit_level_save_make_option_string(i);
		if(next_header != NULL)
			fprintf(asm_file, "\t.byte %s\n", next_header);
		else
		{
			// This really should NEVER happen!!
			alert("INTERNAL ERROR: A generated header line was too long!", NULL, NULL, "OK", NULL, 0, 0);
			fclose(asm_file);
		}
	}

	// Pack the level
	level_data = NoDice_pack_level(&size, 0);

	// Write it out, byte-for-byte, 16 bytes per row
	fprintf(asm_file, "\n\t.byte ");
	for(i = 0; i < size; i++)
	{
		fprintf(asm_file, "$%02X", level_data[i]);

		if(++col == 16)
		{
			fprintf(asm_file, "\n\t.byte ");
			col = 0;
		}
		else if(i < (size-1))
			fprintf(asm_file, ", ");
	}

	fclose(asm_file);

	// Now ... initiate the build!!
	build_err = NoDice_DoBuild();

	// FIXME: Alert does a terrible job of printing, but hopefully the editor
	// never spits out invalid data and further you weren't screwing with
	// the assembler source too much before you ran this...
	if(build_err != NULL)
		alert(build_err, NULL, NULL, "OK", NULL, 0, 0);
	else
		alert("Save and build complete!", NULL, NULL, "OK", NULL, 0, 0);
}
