#include <allegro.h>
#include <stdio.h>
#include "NoDiceLib.h"
#include "NoDice.h"

struct _gui_gen_state gui_gen_state;

//////////////////////////////////////////////////////////////////////////////
// GENERATOR EDITOR
//////////////////////////////////////////////////////////////////////////////

static const char *generator_listget(int index, int *list_size)
{

	if(index < 0)
	{
		*list_size = NoDice_the_level.tileset->gen_count;
		return NULL;
	}
	else
	{
		return NoDice_the_level.tileset->generators[index].name;
	}
}


static int button_save(void)
{
	edit_level_save();

	return D_O_K;
}


enum DLEVELEDIT_CONTROLS
{
	DLEVED_CLEAR,		// Not useful

	DLEVED_COMBOBOX,	// d_combobox_proc
	DLEVED_TEXT1,		// d_text_proc
	DLEVED_SPIN1,		// d_spinedit_proc
	DLEVED_TEXT2,		// d_text_proc
	DLEVED_SPIN2,		// d_spinedit_proc

	DLEVED_SAVE,		// d_push_button_proc

	DLEVED_YIELD,		// not useful
	DLEVED_NULL,		// not useful
	DLEVED_TOTAL
};

DIALOG d_level_edit[DLEVED_TOTAL] =
{
	/* (dialog proc)     (x)   (y)   (w)   (h) (fg)(bg) (key) (flags)     (d1) (d2)    (dp)                   (dp2) (dp3) */
	{ d_clear_proc,        0,   0,    0,    0,   0,  0,    0,      0,       0,   0,    NULL,                   NULL, NULL  },

	{ d_combobox_proc,     8,  44,  256,  384,   0,  0,    0,      0,       0,   0,    (void *)generator_listget, NULL,  NULL  },

	{ d_text_clearrect_proc,0,  92,  192,    0,   0,  0,    0,      0,       0,   0,    (void*)"Width:",  NULL, NULL  },
	{ d_spinedit_proc,   192,  92,   64,   24,   0,  0,    0,      0,       0,   0,    NULL,      NULL, SPINRANGE(0, 15)  },

	{ d_text_clearrect_proc,0, 140,  192,    0,   0,  0,    0, D_DISABLED,   0,   0,    (void*)"N/A:",  NULL, NULL  },
	{ d_spinedit_proc,   192, 140,   64,   24,   0,  0,    0, D_DISABLED,   0,   0,    NULL,      NULL, SPINRANGE(0, 255)  },

	{ d_push_button_proc,  8,  16,  160,   16,   0,  0,    0, D_EXIT,       0,   0,    (void*)"Save",            button_save, NULL  },

	{ d_yield_proc,        0,   0,    0,    0,   0,  0,    0,      0,       0,   0,    NULL,                   NULL, NULL  },
	{ NULL,                0,   0,    0,    0,   0,  0,    0,      0,       0,   0,    NULL,                   NULL, NULL  }

   //{ d_push_button_proc,328,   6,  160,   16,   0,  0,    0, D_EXIT,       0,   0,    (void*)"OK",            awfuck, NULL  },
   //{ d_text_proc,         0,  10,    0,    0,   0,  0,    0,      0,       0,   0,    (void*)"enter number",  NULL, NULL  },
   //{ d_edit_proc,       160,  10,  160,    8,   0,  0,    0,      0,      64,   0,    (void*)the_string,      NULL, NULL  },
   //{ d_list_proc,         0, 150,  120,   44,   0,  0,    0,      0,       2,   0,    (void *)generator_listget, sel,  NULL  },
};


// Quick routine to return a proper label name or (Undefined)
static const char *get_label_or_default(const char *label)
{
	return (label != NULL) ? label : "(Undefined)";
}


static void gui_enable_controls_for_gen(struct NoDice_generator *gen, int gen_size)
{
	// If this is a fixed-size generator, no parameters!
	if(gen->type == GENTYPE_FIXED)
	{
		d_level_edit[DLEVED_TEXT1].dp = "N/A";
		d_level_edit[DLEVED_SPIN1].d1 = 0;

		d_level_edit[DLEVED_TEXT1].flags |= D_DISABLED;
		d_level_edit[DLEVED_SPIN1].flags |= D_DISABLED;
	}
	else
	{
		d_level_edit[DLEVED_TEXT1].flags &= ~D_DISABLED;
		d_level_edit[DLEVED_SPIN1].flags &= ~D_DISABLED;
	}

	object_message(&d_level_edit[DLEVED_TEXT1], MSG_DRAW, 0);
	object_message(&d_level_edit[DLEVED_SPIN1], MSG_DRAW, 0);

	// If this generator size > 3, enable the additional parameter
	if(gen_size > 3)
	{
		// Not disabled!
		d_level_edit[DLEVED_TEXT2].flags &= ~D_DISABLED;
		d_level_edit[DLEVED_SPIN2].flags &= ~D_DISABLED;
	}
	else
	{
		// Otherwise, disable them
		d_level_edit[DLEVED_TEXT2].dp = "N/A";
		d_level_edit[DLEVED_SPIN2].d1 = 0;

		d_level_edit[DLEVED_TEXT2].flags |= D_DISABLED;
		d_level_edit[DLEVED_SPIN2].flags |= D_DISABLED;
	}

	object_message(&d_level_edit[DLEVED_TEXT2], MSG_DRAW, 0);
	object_message(&d_level_edit[DLEVED_SPIN2], MSG_DRAW, 0);
}


static void gui_set_labels_and_ranges_for_gen(struct NoDice_generator *gen, int gen_size)
{
	if(gen->type != GENTYPE_FIXED)
	{
		// Set parameter label
		d_level_edit[DLEVED_TEXT1].dp = (void *)get_label_or_default(gen->parameters[0].name);

		// Set ranges
		d_level_edit[DLEVED_SPIN1].dp3 = SPINRANGE(gen->parameters[0].min, gen->parameters[0].max);
		if(d_level_edit[DLEVED_SPIN1].d1 < gen->parameters[0].min)
			d_level_edit[DLEVED_SPIN1].d1 = gen->parameters[0].min;
		else if(d_level_edit[DLEVED_SPIN1].d1 > gen->parameters[0].max)
			d_level_edit[DLEVED_SPIN1].d1 = gen->parameters[0].max;
	}

	// If this generator size > 3, enable the additional parameter
	if(gen_size > 3)
	{
		// Set parameter label
		d_level_edit[DLEVED_TEXT2].dp = (void *)get_label_or_default(gen->parameters[1].name);

		// Set ranges
		d_level_edit[DLEVED_SPIN2].dp3 = SPINRANGE(gen->parameters[1].min, gen->parameters[1].max);
		if(d_level_edit[DLEVED_SPIN2].d1 < gen->parameters[1].min)
			d_level_edit[DLEVED_SPIN2].d1 = gen->parameters[1].min;
		else if(d_level_edit[DLEVED_SPIN2].d1 > gen->parameters[1].max)
			d_level_edit[DLEVED_SPIN2].d1 = gen->parameters[1].max;
	}
}


void d_level_edit_updateForSelect()
{
	// Need to match up the selected level generator with the configured one
	int i;

	if(ppu_selected_generator.gen == NULL)
		return;

	for(i = 0; i < NoDice_the_level.tileset->gen_count; i++)
	{
		struct NoDice_generator *gen = &NoDice_the_level.tileset->generators[i];

		if(	gen->id == ppu_selected_generator.gen->id &&
			gen->type == ppu_selected_generator.gen->type)
		{
			// Found it!
			d_level_edit[DLEVED_COMBOBOX].d1 = i;
			object_message(&d_level_edit[DLEVED_COMBOBOX], MSG_DRAW, 0);

			if(gen->type != GENTYPE_FIXED)
			{
				// Push generator value into first spin control
				d_level_edit[DLEVED_SPIN1].d1 = ppu_selected_generator.gen->p[0];
				gui_gen_state.p[0] = d_level_edit[DLEVED_SPIN1].d1;
			}

			// If this generator size > 3, enable the additional parameter
			if(ppu_selected_generator.gen->size > 3)
			{
				// Push generator value into first spin control
				d_level_edit[DLEVED_SPIN2].d1 = ppu_selected_generator.gen->p[1];
				gui_gen_state.p[1] = d_level_edit[DLEVED_SPIN2].d1;
			}

			// Set spin control labels for generator
			gui_set_labels_and_ranges_for_gen(gen, ppu_selected_generator.gen->size);

			// Properly enable controls for this generator
			gui_enable_controls_for_gen(gen, ppu_selected_generator.gen->size);

			// We just set the values, so they're NOT dirty!
			gui_gen_state.dirty = 0;

			break;
		}
	}
}


void gui_state_update()
{
	// Selected generator
	struct NoDice_generator *droplist_gen = &NoDice_the_level.tileset->generators[d_level_edit[DLEVED_COMBOBOX].d1];
	if(droplist_gen != gui_gen_state.selected_gen)
	{
		int i, size = 3;

		// If selected generator changed, need to update the spin control labels/enables
		// Count defined parameters to get a size...
		for(i = 1; i < GEN_MAX_PARAMS && droplist_gen->parameters[i].name != NULL; i++)
			size++;

		// Set spin control labels for generator
		gui_set_labels_and_ranges_for_gen(droplist_gen, size);

		// Properly enable controls for this generator
		gui_enable_controls_for_gen(droplist_gen, size);

		// Set which generator we've selected now
		gui_gen_state.selected_gen = droplist_gen;

		// Also, deselect any selection; we don't support dynamically
		// changing a generator, and in any case this will screw it up
		ppu_selected_generator.gen = NULL;
	}

	// Parameter 1
	if(gui_gen_state.p[0] != d_level_edit[DLEVED_SPIN1].d1)
	{
		gui_gen_state.p[0] = d_level_edit[DLEVED_SPIN1].d1;
		gui_gen_state.dirty = 1;
	}

	// Parameter 2
	if(gui_gen_state.p[1] != d_level_edit[DLEVED_SPIN2].d1)
	{
		gui_gen_state.p[1] = d_level_edit[DLEVED_SPIN2].d1;
		gui_gen_state.dirty = 1;
	}
}
