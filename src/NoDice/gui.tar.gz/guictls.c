#include <allegro.h>
#include <stdio.h>
#include "NoDiceLib.h"
#include "NoDice.h"

int d_close_click_outside_proc(int msg, DIALOG *d, int c)
{
	// Close dialog when user clicks outside the boundaries of the "popup"
	if(	(gui_mouse_b() & 1) &&
		((gui_mouse_x() < d->x) || (gui_mouse_x() > d->x + d->w) ||
		 (gui_mouse_y() < d->y) || (gui_mouse_y() > d->y + d->h)))
		 return D_CLOSE;

	return D_O_K;
}

int d_push_button_proc(int msg, DIALOG *d, int c)
{
	int ret = d_button_proc(msg, d, c);

	int (*proc)(void *);

	if(ret == D_CLOSE)
	{
		scare_mouse();
		object_message(d, MSG_DRAW, 0);
		unscare_mouse();
		proc = d->dp2;
		if(proc)
			return proc(d->dp3);

		return D_O_K;
	}
	else
		return ret;
}


// Built-in special popup to allow user to type freely into spin edit control
static char spinedit_editbuf[7*4];	// built-in buffer for editing spin edit control
static DIALOG editmode[] =
{
	/* (dialog proc)     (x)   (y)   (w)   (h) (fg)(bg) (key) (flags)     (d1) (d2)    (dp)                   (dp2) (dp3) */
	{ d_close_click_outside_proc,     0,   0,    0,    0,   0,  0,    0,      0,       0,   0,    NULL,                   NULL, NULL  },
	{ d_edit_proc,    0,   0,    0,    0,   0,  0,    0,   D_EXIT,         0,   0,    spinedit_editbuf,                   NULL, NULL  },
	{ d_yield_proc,        0,   0,    0,    0,   0,  0,    0,      0,       0,   0,    NULL,                   NULL, NULL  },
	{ NULL,                0,   0,    0,    0,   0,  0,    0,      0,       0,   0,    NULL,                   NULL, NULL  }
};

int d_spinedit_proc(int msg, DIALOG *d, int c)
{
	int x, yt, ym, yb;
	int bg = gui_bg_color;
	int fg = (d->flags & D_DISABLED) ? gui_mg_color : d->fg;

	short min = (short)(((int)d->dp3 ) >> 16);
	short max = (short)(((int)d->dp3 ) & 0xFFFF);

	x = d->x + d->w - 16;
	yt = d->y - 1;
	ym = d->y + (d->h / 2);
	yb = d->y + d->h + 1;

	if (msg == MSG_DRAW)
	{
		// Wrap a rectangle dammit
		rectfill(screen, d->x, d->y, d->x + d->w, d->y + d->h, bg);
		rect(screen, d->x - 1, d->y - 1, d->x + d->w + 1, d->y + d->h + 1, fg);

		// Draw number
		textprintf_ex(screen, font, d->x, d->y, fg, bg, "%i", d->d1);

		// Draw spin
		rect(screen, x, yt, x+16, yb, fg);
		hline(screen, x, ym, x + 16, fg);

		triangle(screen, x + 8, yt + 2, x + 2, ym - 2, x + 14, ym - 2, fg);
		triangle(screen, x + 8, yb - 2, x + 2, ym + 2, x + 14, ym + 2, fg);

		return D_O_K;
	}
	else if(msg == MSG_CLICK)
	{
		// As long as mouse is within "edit" area, pop up an editor
		if(gui_mouse_x() < x)
		{
			int i;

			// Going to popup the list!  Need to configure it...
			for(i = 0; i < 2; i++)
			{
				editmode[i].x = d->x;
				editmode[i].y = d->y;
				editmode[i].w = d->w - 16;
				editmode[i].h = d->h;
				editmode[i].d1 = d->d1;

				if(editmode[i].proc == d_edit_proc)
				{
					// Set max chars based on whether negative values are allowed
					editmode[i].d1 = (min < 0) ? 6 : 5;
				}
			}

			// Set buffer to current value of d1
			sprintf(spinedit_editbuf, "%i", d->d1);

			// Set cursor to end of buffer
			d->d2 = strlen(spinedit_editbuf);

			set_dialog_color (editmode, fg, bg);
			popup_dialog(editmode, 0);

			// Update because user may have changed value
			d->d1 = atoi(spinedit_editbuf);
			d->flags |= D_DIRTY;

			// Range check!
			if(d->d1 < min)
				d->d1 = min;
			else if(d->d1 > max)
				d->d1 = max;
		}
		else
		{
			if(gui_mouse_y() >= ym)
			{
				// Bottom spin
				if(d->d1 > min)
					d->d1--;
			}
			else
			{
				// Top spin
				if(d->d1 < max)
					d->d1++;
			}

			if(d->d1 < min)
				d->d1 = min;
			else if(d->d1 > max)
				d->d1 = max;

			d->flags |= D_DIRTY;
		}
	}

	return D_O_K;
}

/* typedef for the listbox callback functions */
typedef char *(*getfuncptr)(int, int *);

static int d_text_list_clickclose_proc(int msg, DIALOG *d, int c)
{
	int retval = d_text_list_proc(msg, d, c);

	// Any click in the list will close it
	if(msg == MSG_CLICK)
	{
		int listsize, height, bar;

		(*(getfuncptr)d->dp)(-1, &listsize);
		height = (d->h-4) / text_height(font);
		bar = (listsize > height);

		// Only close if mouse is on item, not the scrollbar
		if ((!bar) || (gui_mouse_x() < d->x+d->w-13))
		{
			retval = D_CLOSE;
		}
	}

	return retval;
}


static DIALOG combolist[] =
{
	/* (dialog proc)     (x)   (y)   (w)   (h) (fg)(bg) (key) (flags)     (d1) (d2)    (dp)                   (dp2) (dp3) */
	{ d_close_click_outside_proc,     0,   0,    0,    0,   0,  0,    0,      0,       0,   0,    NULL,                   NULL, NULL  },
	{ d_text_list_clickclose_proc,    0,   0,    0,    0,   0,  0,    0,   D_EXIT,       0,   0,    NULL,                   NULL, NULL  },
	{ d_yield_proc,        0,   0,    0,    0,   0,  0,    0,      0,       0,   0,    NULL,                   NULL, NULL  },
	{ NULL,                0,   0,    0,    0,   0,  0,    0,      0,       0,   0,    NULL,                   NULL, NULL  }
};


int d_combobox_proc(int msg, DIALOG *d, int c)
{
	// 24 base height as just the top part
	int baseheight = 24;
	int retval = D_O_K;
	int bg = gui_bg_color, fg = (d->flags & D_DISABLED) ? gui_mg_color : gui_fg_color;

	if(msg == MSG_DRAW)
	{
		char onechar[2] = { 0 };

		int px = d->x + d->w - 16, text_x = d->x + 1, text_width_remain = px - d->x;
		const char *str = (*(getfuncptr)d->dp)(d->d1, NULL);

		rectfill(screen, d->x+1, d->y+1, d->x + d->w - 1, d->y + baseheight - 1, bg);
		rect(screen, d->x, d->y, d->x + d->w, d->y + baseheight, fg);
		vline(screen, px, d->y, d->y + baseheight, fg);

		triangle(screen, px + 2, d->y + 6, px + 14, d->y + 6, px + 8, d->y + baseheight - 6, fg);

		while(*str != '\0')
		{
			int len;

			// Get next character, form the onechar string
			onechar[0] = *str++;

			// Deduct length of this character
			len = text_length(font, onechar);
			text_width_remain -= len;

			if(text_width_remain >= 0)
				// Print next character
				textout_ex(screen, font, onechar, text_x, d->y + 1, fg, -1);
			else
				// Out of room; quit!
				break;

			// Advance
			text_x += len;
		}
	}
	else if(msg == MSG_CLICK)
	{
		// Clicked; in range of baseheight?
		if((gui_mouse_y() - d->y) < baseheight)
		{
			int i;

			// Going to popup the list!  Need to configure it...
			for(i = 0; i < 2; i++)
			{
				combolist[i].x = d->x;
				combolist[i].y = d->y + ((combolist[i].proc == d_close_click_outside_proc) ? 0 : baseheight);
				combolist[i].w = d->w;
				combolist[i].h = d->h + ((combolist[i].proc == d_close_click_outside_proc) ? baseheight : 0);
				combolist[i].dp = d->dp;
				combolist[i].d1 = d->d1;
			}

			set_dialog_color (combolist, fg, bg);
			popup_dialog(combolist, 0);

			// Update because user may have changed selection
			d->d1 = combolist[1].d1;
			d->flags |= D_DIRTY;
		}
	}

	return retval;
}


// MOSTLY the same as d_text_proc, except when drawing,
// it clears out a rectangle behind the text
int d_text_clearrect_proc(int msg, DIALOG *d, int c)
{
	if(msg == MSG_DRAW)
		rectfill(screen, d->x, d->y, d->x + d->w, d->y + text_height(font), gui_bg_color);

	return d_text_proc(msg, d, c);
}
