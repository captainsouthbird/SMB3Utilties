#include <allegro.h>
#include "NoDiceLib.h"
#include "NoDice.h"

extern DIALOG d_level_edit[];

static void set_color_rgb(unsigned char color, unsigned char r, unsigned char g, unsigned char b)
{
	RGB rgb =  { r, g, b };
	set_color(color, &rgb);
}

int main()
{
	allegro_init();

	if((font = load_font("font.pcx", NULL, NULL)) == NULL)
	{
		allegro_message("Failed to load font!");
		return 1;
	}

	if(!NoDice_Init())
	{
		allegro_message("%s\n", NoDice_Error());

		NoDice_Shutdown();

		return 1;
	}

	set_color_depth(8);
	set_gfx_mode(GFX_AUTODETECT_WINDOWED, 800, 600, 0, 0);
	install_timer();
	install_keyboard();
	install_mouse();

	// Lock 6502 timeout stuff
	LOCK_VARIABLE(NoDice_Run6502_Stop);
	LOCK_FUNCTION(edit_6502_timeout);

	ppu_init();

	show_mouse(screen);

	set_color_rgb(253, 0, 0, 0);
	set_color_rgb(254, 32, 32, 32);
	set_color_rgb(255, 57, 56, 55);

	gui_fg_color = 253;
	gui_mg_color = 254;
	gui_bg_color = 255;
	set_dialog_color (d_level_edit, gui_fg_color, gui_bg_color);

	gui_mouse_focus = 0;

	// FIXME: REMOVE THIS LATER
	edit_level_load(8, &NoDice_config.game.tilesets[7].levels[1]);

	ppu_configure_for_level();

	{
		DIALOG_PLAYER *player = init_dialog(d_level_edit, 0);
		update_dialog(player);

		// Call once for default selected generator
		gui_state_update();

		while(!key[KEY_ESC])
		{
			scare_mouse();

			if( 	gui_gen_state.dirty ||
				(mouse_x >= PPU_PORTAL_X && mouse_y >= PPU_PORTAL_Y && mouse_x <= PPU_PORTAL_X + 512 && mouse_y <= PPU_PORTAL_Y + 512)
				)
			{
				clear_keybuf();
				edit_do();
				ppu_draw();
			}
			else
			{
				update_dialog(player);
				gui_state_update();
			}


			stretch_blit(PPU_portal, screen, 0, 0, PPU_portal->w, PPU_portal->h, PPU_PORTAL_X, PPU_PORTAL_Y, 512, 512);

			unscare_mouse();
			vsync();
		}

		shutdown_dialog(player);
	}

	//allegro_message("You entered %f.", uatof(the_string));

	ppu_shutdown();

	NoDice_Shutdown();

	return 0;
}
END_OF_MAIN()
