#include <allegro.h>
#include "NoDiceLib.h"
#include "NoDice.h"

BITMAP *PPU_portal;
static BITMAP *PPU_BG_VROM[4];

struct _ppu_selected_generator ppu_selected_generator = { 0 };

	// Based on http://nesdev.parodius.com/pal.txt, Allegro-ified
static const PALETTE NES_pal = {
	{ 0x1D,0x1D,0x1D }, { 0x09,0x06,0x23 }, { 0x00,0x00,0x2A }, { 0x11,0x00,0x27 },	// 00
	{ 0x23,0x00,0x1D }, { 0x2A,0x00,0x04 }, { 0x29,0x00,0x00 }, { 0x1F,0x02,0x00 },	// 04
	{ 0x10,0x0B,0x00 }, { 0x00,0x11,0x00 }, { 0x00,0x14,0x00 }, { 0x00,0x0F,0x05 },	// 08
	{ 0x06,0x0F,0x17 }, { 0x00,0x00,0x00 }, { 0x00,0x00,0x00 }, { 0x00,0x00,0x00 },	// 0C
	{ 0x2F,0x2F,0x2F }, { 0x00,0x1C,0x3B }, { 0x08,0x0E,0x3B }, { 0x20,0x00,0x3C },	// 10
	{ 0x2F,0x00,0x2F }, { 0x39,0x00,0x16 }, { 0x36,0x0A,0x00 }, { 0x32,0x13,0x03 },	// 14
	{ 0x22,0x1C,0x00 }, { 0x00,0x25,0x00 }, { 0x00,0x2A,0x00 }, { 0x00,0x24,0x0E },	// 18
	{ 0x00,0x20,0x22 }, { 0x00,0x00,0x00 }, { 0x00,0x00,0x00 }, { 0x00,0x00,0x00 },	// 1C
	{ 0x3F,0x3F,0x3F }, { 0x0F,0x2F,0x3F }, { 0x17,0x25,0x3F }, { 0x29,0x22,0x3F },	// 20
	{ 0x3D,0x1E,0x3F }, { 0x3F,0x1D,0x2D }, { 0x3F,0x1D,0x18 }, { 0x3F,0x26,0x0E },	// 24
	{ 0x3C,0x2F,0x0F }, { 0x20,0x34,0x04 }, { 0x13,0x37,0x12 }, { 0x16,0x3E,0x26 },	// 28
	{ 0x00,0x3A,0x36 }, { 0x00,0x00,0x00 }, { 0x00,0x00,0x00 }, { 0x00,0x00,0x00 },	// 2C
	{ 0x3F,0x3F,0x3F }, { 0x2A,0x39,0x3F }, { 0x31,0x35,0x3F }, { 0x35,0x32,0x3F },	// 30
	{ 0x3F,0x31,0x3F }, { 0x3F,0x31,0x36 }, { 0x3F,0x2F,0x2C }, { 0x3F,0x36,0x2A },	// 34
	{ 0x3F,0x39,0x28 }, { 0x38,0x3F,0x28 }, { 0x2A,0x3C,0x2F }, { 0x2C,0x3F,0x33 },	// 38
	{ 0x27,0x3F,0x3C }, { 0x00,0x00,0x00 }, { 0x00,0x00,0x00 }, { 0x00,0x00,0x00 }	// 3C
};

void ppu_init()
{
	// Set default palette (TO BE REMOVED)
	int cbase;
	PALETTE pal;
	memcpy(pal, default_palette, sizeof(PALETTE));

	for(cbase = 0; cbase < 32; cbase += 4)
	{
		pal[cbase+0].r = 0;
		pal[cbase+0].g = 0;
		pal[cbase+0].b = 0;

		pal[cbase+1].r = 21;
		pal[cbase+1].g = 21;
		pal[cbase+1].b = 21;

		pal[cbase+2].r = 42;
		pal[cbase+2].g = 42;
		pal[cbase+2].b = 42;

		pal[cbase+3].r = 63;
		pal[cbase+3].g = 63;
		pal[cbase+3].b = 63;
	}

	set_palette(pal);

	PPU_portal = create_bitmap(256,256);
	clear_bitmap(PPU_portal);

	// Create linear space, enough for 256 tiles, 4 times
	// (different palettes, maybe there's a better way?)
	for(cbase = 0; cbase < 4; cbase++)
		PPU_BG_VROM[cbase] = create_bitmap(8, 256*8);
}


// In MMC3, the BG bank setting actually uses two adjacent banks
// (that is, it swaps in 2KB / 128 tiles in "halves")
// This imitates that behavior accordingly...
//
//MMC3_2K_TO_PPU_0000	= %01000000	; 0
//MMC3_2K_TO_PPU_0800	= %01000001	; 1
//
// So if to0800 is non-zero, it adds to the "bottom half"
void ppu_set_BG_bank(unsigned char bank, unsigned char to0800)
{
	int 	startrow = to0800 ? 128*8 : 0,
		endrow = startrow + 128*8,
		row;
	const unsigned char *VROM_start = NoDice_get_raw_CHR_bank(bank), *VROM;
	int pal, cbase;

	// Generate all four palette copies (seems wasteful; better way?)
	for(pal = 0; pal < 4; pal++)
	{
		VROM = VROM_start;
		cbase = pal << 2;

		// This actually goes through two banks, but works because it's linear
		// Except if, somehow, you specified the last bank...
		for(row = startrow; row < endrow; row++)
		{
			_putpixel(PPU_BG_VROM[pal], 0, row, *(VROM++) + cbase);
			_putpixel(PPU_BG_VROM[pal], 1, row, *(VROM++) + cbase);
			_putpixel(PPU_BG_VROM[pal], 2, row, *(VROM++) + cbase);
			_putpixel(PPU_BG_VROM[pal], 3, row, *(VROM++) + cbase);
			_putpixel(PPU_BG_VROM[pal], 4, row, *(VROM++) + cbase);
			_putpixel(PPU_BG_VROM[pal], 5, row, *(VROM++) + cbase);
			_putpixel(PPU_BG_VROM[pal], 6, row, *(VROM++) + cbase);
			_putpixel(PPU_BG_VROM[pal], 7, row, *(VROM++) + cbase);
		}
	}
}


void ppu_configure_for_level()
{
	int c;

	// Set banks (loads VROM)
	ppu_set_BG_bank(NoDice_the_level.bg_page_1, 0);
	ppu_set_BG_bank(NoDice_the_level.bg_page_2, 1);

	// Set BG palette
	for(c = 0; c < 16; c++)
	{
		set_color(c, &NES_pal[NoDice_the_level.bg_pal[c]]);
	}
}


// Defines a bounding rectangle around a generator (screen-relative)
struct ppu_bound_rect
{
	int xs, ys;
	int xe, ye;
};

// Draws a ppu_bound_rect
static void ppu_draw_bound_rect(struct ppu_bound_rect *br, int color)
{
	rect(PPU_portal, br->xs, br->ys, br->xe, br->ye, 253);
	rect(PPU_portal, br->xs-1, br->ys-1, br->xe+1, br->ye+1, color);
	rect(PPU_portal, br->xs-2, br->ys-2, br->xe+2, br->ye+2, 253);
}


// Returns non-zero if mouse is inside a generator bound
static int ppu_find_mouse_in_gen(int rel_mouse_x, int rel_mouse_y, int pan_x, int pan_y, struct NoDice_the_level_generator *gen, struct ppu_bound_rect *br)
{
	// Calculate the screen-relative ppu_bound_rect
	br->xs = gen->xs - pan_x;
	br->ys = gen->ys - pan_y;
	br->xe = gen->xe - pan_x;
	br->ye = gen->ye - pan_y;

	return
		(rel_mouse_x >= br->xs && rel_mouse_x <= br->xe &&
		rel_mouse_y >= br->ys && rel_mouse_y <= br->ye);
}


// Scans all level's generators for whether mouse is inside any of them, and iterates selection
static void ppu_find_mouse_in_gens(int pan_x, int pan_y)
{
	//int _gen_count = 0;

	// Get previous frame value...
	int 	last_frame_value = ppu_selected_generator.frame_counter - 1,

		// "Levels" of selection before we hit next target
		potential_sel_level = ppu_selected_generator.select_level;

	struct NoDice_the_level_generator
		// Keep a pointer to first possible selected generator in case we're at last possible selected generator
		*select_first_possible = NULL,

		// Keep a pointer at the generator selected at user's selection level;
		// only valid if the selection pool didn't change from last time...
		*select_atlevel_possible = NULL;
	struct NoDice_the_level_generator *cur;

	struct ppu_bound_rect br;
	int hilight_color = makecol(255,255,255);
	static int mouse_click_flag = 0, mouse_drag_possible = 0;

	int rel_mouse_x = (mouse_x - PPU_PORTAL_X) / 2;
	int rel_mouse_y = (mouse_y - PPU_PORTAL_Y) / 2;

	if(rel_mouse_x >= 0 && rel_mouse_x <= 255 && rel_mouse_y >= 0 && rel_mouse_y <= 255)
	{
		if(gui_gen_state.insert_mode.state == 0)
		{
			if(mouse_b & 1)
			{
				if( (mouse_click_flag == 0) && (ppu_selected_generator.gen != NULL) )
				{
					mouse_drag_possible =
						ppu_find_mouse_in_gen(rel_mouse_x, rel_mouse_y, pan_x, pan_y, ppu_selected_generator.gen, &br);
				}

				mouse_click_flag = 1;
			}
			else if(mouse_click_flag == 1)
			{
				// User has completed click
				mouse_click_flag = 2;

				// Since the user has clicked, we need to reconsider the selection
				ppu_selected_generator.gen = NULL;
			}

			cur = NoDice_the_level.generators;
			while(cur != NULL)
			{
				if(cur->type != GENTYPE_JCTSTART)
				{
					if(ppu_find_mouse_in_gen(rel_mouse_x, rel_mouse_y, pan_x, pan_y, cur, &br))
					{
						// Test if the generator was in the previous selection set; if not,
						// then invalidate the selection level
						if(cur->sel_last_frame != last_frame_value)
							potential_sel_level = -1;

						// Draw rectangle around possibly selectable generator
						ppu_draw_bound_rect(&br, hilight_color);

						// If this is the FIRST POSSIBLY selected generator, mark it
						if(select_first_possible == NULL)
							select_first_possible = cur;

						// Only select this one if we're at the right level!
						if((potential_sel_level == 0) && (select_atlevel_possible == NULL))
						{
							// Selected!
							select_atlevel_possible = cur;
						}
						else if(potential_sel_level > 0)
							potential_sel_level--;

						// This generator is in the potential selection set; update its frame value
						cur->sel_last_frame = ppu_selected_generator.frame_counter;
					}
						// Test if the generator was in the previous selection set; if it was,
						// then invalidate the selection level because it's not anymore!
					else if(cur->sel_last_frame == last_frame_value)
					{
						potential_sel_level = -1;

						// And so we reset the selection level too!
						ppu_selected_generator.select_level = 0;
					}

				}

				cur = cur->next;
				//_gen_count++;
			}

			if(select_first_possible == NULL)
				potential_sel_level = -1;

			if(mouse_click_flag == 2)
			{
				if(select_first_possible != NULL)
				{
					// If "select_first_possible" is not null but "select_atlevel_possible"
					// is null, then user wrapped around their choice pool, so use the first.
					// Otherwise, use the at-level selection...
					// Also, if potential_sel_level fell below zero, that means there was a
					// generator not in the previous or missing from the previous pool.
					if(select_atlevel_possible == NULL || potential_sel_level < 0)
					{
						// Either we're back on the first of a selection pool or the
						// selection pool changed; in any case, select the first
						ppu_selected_generator.gen = select_first_possible;

						// And so we reset the selection level too!
						ppu_selected_generator.select_level = 1;
					}
					else
					{
						// We selected at-level; set it!
						ppu_selected_generator.gen = select_atlevel_possible;

						// Up the level for next time...
						ppu_selected_generator.select_level++;
					}

					// Update UI
					d_level_edit_updateForSelect();
				}

				if(ppu_selected_generator.gen != NULL)
				{
					// Haven't moved yet...
					ppu_selected_generator.moved_yet = 0;

					// Capture mouse absolute X/Y
					ppu_selected_generator.mouse_start_abs_x = pan_x + rel_mouse_x;
					ppu_selected_generator.mouse_start_abs_y = pan_y + rel_mouse_y;

					// Set current RELATIVE row and column
					ppu_selected_generator.mouse_last_row = 0;
					ppu_selected_generator.mouse_last_col = 0;
				}

				// Reset user's click flag
				mouse_click_flag = 0;
				mouse_drag_possible = 0;
			}
		}
		else if(gui_gen_state.insert_mode.state == 1)
		{
			// Insert mode
			int 	abs_x = rel_mouse_x + pan_x,
				abs_y = rel_mouse_y + pan_y;
			int 	row = abs_y / TILESIZE,
				col = abs_x / TILESIZE;

			int offx = (pan_x & 0xF), offy = (pan_y & 0xF);
			int 	x = ((rel_mouse_x + offx) & ~15) - offx,
				y = ((rel_mouse_y + offy) & ~15) - offy;

			// Nothing is selected in insert mode
			ppu_selected_generator.gen = NULL;

			// Draw tile-aligned cursor
			rect(PPU_portal, x, y, x+TILESIZE-1, y+TILESIZE-1, 255);

			if(mouse_b & 1)
			{
				if(!(NoDice_the_level.header.is_vert))
				{
					gui_gen_state.insert_mode.addr = (col / SCREEN_WIDTH * SCREEN_BYTESIZE) + (row * SCREEN_WIDTH) + (col % SCREEN_WIDTH);
				}
				else
				{
					gui_gen_state.insert_mode.addr = (row * SCREEN_WIDTH) + col;
				}

				// Address moved to RAM placement
				gui_gen_state.insert_mode.addr += 0x6000;

				// That's enough for this side, tell edit side we're ready
				gui_gen_state.insert_mode.state = 2;
			}
		}
	}


	if(ppu_selected_generator.gen != NULL)
	{
		br.xs = ppu_selected_generator.gen->xs - pan_x,
		br.ys = ppu_selected_generator.gen->ys - pan_y,
		br.xe = ppu_selected_generator.gen->xe - pan_x,
		br.ye = ppu_selected_generator.gen->ye - pan_y;

		ppu_draw_bound_rect(&br, makecol(0,255,0));

		//textprintf_ex(PPU_portal, font, 0, 0, makecol(255,255,255), 0, "%i %i", ppu_selected_generator.gen->xs, ppu_selected_generator.gen->ys);

		// Click n' drag...
		if(mouse_drag_possible)
		{
			// Current absolute X/Y
			int abs_x = (pan_x + rel_mouse_x);
			int abs_y = (pan_y + rel_mouse_y);

			// We need to see if we've moved an entire row or column, so our row/column is relative
			int rel_row = (abs_y - ppu_selected_generator.mouse_start_abs_y) / TILESIZE;
			int rel_col = (abs_x - ppu_selected_generator.mouse_start_abs_x) / TILESIZE;

			// Difference from row/col we WERE on
			int diff_row = rel_row - ppu_selected_generator.mouse_last_row;
			int diff_col = rel_col - ppu_selected_generator.mouse_last_col;

			if(diff_row != 0 || diff_col != 0)
			{
				edit_transform_sel_gen(diff_row, diff_col);
			}

			// Set current row and column
			ppu_selected_generator.mouse_last_row = rel_row;
			ppu_selected_generator.mouse_last_col = rel_col;
		}
	}

	// Increment the frame counter...
	ppu_selected_generator.frame_counter++;

	//textprintf_ex(PPU_portal, font, 0, 0, makecol(255,255,255), 0, "%i", _gen_count);
}


#define ppu_draw_pattern(x, y, pat, pal) blit(PPU_BG_VROM[pal], PPU_portal, 0, (pat) << 3, (x), (y), 8, 8)


void ppu_draw()
{
	static int pan_x = 0, pan_y = 0;
	int pan_limit_x, pan_limit_y;

	int start_x = -(pan_x & 0xF), x = start_x, y = -(pan_y & 0xF);
	int row = pan_y >> 4;
	int row_end = row + (256 / 16 + 1);
	int col_start = pan_x >> 4, col = col_start;
	int col_end = col_start + (256 / 16 + 1);

	unsigned char screen, col_ef;
	unsigned char pal, tile;
	unsigned short offset;

	if(!NoDice_the_level.header.is_vert)
	{
		// Pan limits for non-vertical level

		// Non-vertical level is made up 15 screens of
		// SCREEN_WIDTH tile columns, each TILESIZE
		// pixels wide... but we don't want to scroll
		// onto the last 256 pixels...
		pan_limit_x = (SCREEN_WIDTH * TILESIZE * 15) - 256;

		// Take the total size of the screen SCREEN_BYTESIZE
		// and divide it by the number of tiles in a row
		// SCREEN_WIDTH and you have total rows; multiply by
		// TILESIZE to get the size in pixels, and subtract
		// 256 to keep the visibility correct...
		pan_limit_y = (SCREEN_BYTESIZE / SCREEN_WIDTH * TILESIZE) - 256;
	}
	else
	{
		// Pan limits for vertical level

		// Horizontal is easy -- it doesn't move
		pan_limit_x = 0;

		// SCREEN_BYTESIZE_V / SCREEN_WIDTH gives you the
		// total number of rows per screen; multiply by
		// TILESIZE to get the pixel size and there are 16
		// of the screens.  Again, subtract 256 to keep the
		// visibility correct...
		pan_limit_y = (SCREEN_BYTESIZE_V / SCREEN_WIDTH * TILESIZE * 16) - 256;
	}

	if(key[KEY_LEFT] && pan_x > 0)			pan_x-=8;
	if(key[KEY_RIGHT] && pan_x < pan_limit_x)	pan_x+=8;
	if(key[KEY_UP] && pan_y > 0)				pan_y-=8;
	if(key[KEY_DOWN] && pan_y < pan_limit_y)	pan_y+=8;


	for( ; row < row_end; row++)
	{
		for( ; col < col_end; col++)
		{
			if(!NoDice_the_level.header.is_vert)
			{
				screen = col >> 4;
				col_ef = col & 0xF;
				offset = (screen * SCREEN_BYTESIZE) + (row * SCREEN_WIDTH) + col_ef;
			}
			else
			{
				screen = row / (SCREEN_BYTESIZE_V / SCREEN_WIDTH);	// Not required to figure offset
				col_ef = col & 0xF;
				offset = (row * SCREEN_WIDTH) + col_ef;
			}

			tile = NoDice_the_level.tiles[offset];
			pal = tile >> 6;	// Tile Quadrant defines palette select in SMB3

			ppu_draw_pattern(x+0, y+0, NoDice_the_level.tile_layout[tile][0], pal);
			ppu_draw_pattern(x+0, y+8, NoDice_the_level.tile_layout[tile][1], pal);
			ppu_draw_pattern(x+8, y+0, NoDice_the_level.tile_layout[tile][2], pal);
			ppu_draw_pattern(x+8, y+8, NoDice_the_level.tile_layout[tile][3], pal);

			//ppu_draw_tile(x, y, NoDice_the_level.tiles[offset]);

			x += 16;
		}

		y += 16;

		x = start_x;
		col = col_start;
	}

	ppu_find_mouse_in_gens(pan_x, pan_y);
}


void ppu_shutdown()
{
	int pal;

	destroy_bitmap(PPU_portal);

	for(pal = 0; pal < 4; pal++)
		destroy_bitmap(PPU_BG_VROM[pal]);
}
